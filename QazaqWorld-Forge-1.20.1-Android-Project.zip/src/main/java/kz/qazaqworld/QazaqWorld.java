package kz.qazaqworld;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(QazaqWorld.MOD_ID)
public class QazaqWorld {
    public static final String MOD_ID = "qazaqworld";
    public static final DeferredRegister<Item> ITEMS =
        DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);

    public static final RegistryObject<Item> DOMBYRA = ITEMS.register("dombyra",
        () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> KIIZ_UI = ITEMS.register("kiiz_ui",
        () -> new Item(new Item.Properties().stacksTo(16)));

    public QazaqWorld() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        bus.addListener(this::addCreative);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(this);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(DOMBYRA);
            event.accept(KIIZ_UI);
        }
    }

    @SubscribeEvent
    public void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!event.getEntity().level().isClientSide) {
            event.getEntity().sendSystemMessage(Component.literal(
                "§6Ассалаумағалейкум! §fҚазақ әлеміне қош келдіңіз! 🇰🇿"));
        }
    }

    @SubscribeEvent
    public void onUseItem(PlayerInteractEvent.RightClickItem event) {
        if (event.getLevel().isClientSide) return;
        ItemStack stack = event.getItemStack();
        if (stack.is(DOMBYRA.get())) {
            event.getLevel().playSound(null, event.getPos(),
                SoundEvents.NOTE_BLOCK_BANJO, SoundSource.PLAYERS, 1.0F, 0.8F);
            event.getEntity().sendSystemMessage(Component.literal(
                "§e♪ Домбыра тартылды! Нағыз қазақы күй!"));
        } else if (stack.is(KIIZ_UI.get())) {
            event.getEntity().sendSystemMessage(Component.literal(
                "§fКиіз үй затын кейінгі нұсқада орналастыруға болатын құрылысқа айналдырамыз."));
        }
    }
}
